// ===== COST CALCULATOR =====
const costData = {
  usa: {
    masters: { tuition: 35000, living: { budget: 14000, moderate: 20000, comfortable: 26000 }, insurance: 2500 },
    phd: { tuition: 0, living: { budget: 12000, moderate: 16000, comfortable: 20000 }, insurance: 1500 },
    bachelors: { tuition: 45000, living: { budget: 14000, moderate: 20000, comfortable: 26000 }, insurance: 2500 },
    mba: { tuition: 65000, living: { budget: 18000, moderate: 24000, comfortable: 30000 }, insurance: 3000 }
  },
  canada: {
    masters: { tuition: 22000, living: { budget: 10000, moderate: 14000, comfortable: 18000 }, insurance: 800 },
    phd: { tuition: 8000, living: { budget: 10000, moderate: 13000, comfortable: 17000 }, insurance: 800 },
    bachelors: { tuition: 28000, living: { budget: 10000, moderate: 14000, comfortable: 18000 }, insurance: 800 },
    mba: { tuition: 40000, living: { budget: 14000, moderate: 18000, comfortable: 22000 }, insurance: 1000 }
  },
  germany: {
    masters: { tuition: 400, living: { budget: 8400, moderate: 11000, comfortable: 14000 }, insurance: 1200 },
    phd: { tuition: 300, living: { budget: 8400, moderate: 10000, comfortable: 13000 }, insurance: 1200 },
    bachelors: { tuition: 300, living: { budget: 8400, moderate: 11000, comfortable: 14000 }, insurance: 1200 },
    mba: { tuition: 15000, living: { budget: 9000, moderate: 12000, comfortable: 15000 }, insurance: 1400 }
  },
  uk: {
    masters: { tuition: 26000, living: { budget: 12000, moderate: 16000, comfortable: 21000 }, insurance: 0 },
    phd: { tuition: 20000, living: { budget: 12000, moderate: 15000, comfortable: 20000 }, insurance: 0 },
    bachelors: { tuition: 22000, living: { budget: 12000, moderate: 16000, comfortable: 21000 }, insurance: 0 },
    mba: { tuition: 38000, living: { budget: 15000, moderate: 19000, comfortable: 25000 }, insurance: 0 }
  }
};

const exchangeRates = { usa: 1, canada: 0.74, germany: 1.09, uk: 1.27 };
const currencies = { usa: 'USD', canada: 'CAD', germany: 'EUR', uk: 'GBP' };

function formatBDT(amount) {
  if (amount >= 10000000) return '৳' + (amount / 10000000).toFixed(1) + ' Cr';
  if (amount >= 100000) return '৳' + (amount / 100000).toFixed(1) + ' Lac';
  return '৳' + amount.toLocaleString('en-BD');
}

function calculateCost() {
  const country = document.getElementById('country-sel').value;
  const program = document.getElementById('program-sel').value;
  const lifestyle = document.getElementById('lifestyle-sel').value;
  const usdRate = parseFloat(document.getElementById('rate-input').value) || 110;

  const data = costData[country][program];
  const rate = exchangeRates[country] * usdRate;
  const currency = currencies[country];

  const tuitionForeign = data.tuition;
  const livingForeign = data.living[lifestyle];
  const insuranceForeign = data.insurance;
  const miscForeign = 2000;

  const tuitionBDT = Math.round(tuitionForeign * rate);
  const livingBDT = Math.round(livingForeign * rate);
  const insuranceBDT = Math.round(insuranceForeign * rate);
  const miscBDT = Math.round(miscForeign * rate);
  const totalBDT = tuitionBDT + livingBDT + insuranceBDT + miscBDT;
  const totalForeign = tuitionForeign + livingForeign + insuranceForeign + miscForeign;

  document.getElementById('tuition-bdt').textContent = formatBDT(tuitionBDT);
  document.getElementById('tuition-usd').textContent = currency + ' ' + tuitionForeign.toLocaleString() + '/year';
  document.getElementById('living-bdt').textContent = formatBDT(livingBDT);
  document.getElementById('living-usd').textContent = currency + ' ' + livingForeign.toLocaleString() + '/year';
  document.getElementById('insurance-bdt').textContent = formatBDT(insuranceBDT);
  document.getElementById('insurance-usd').textContent = currency + ' ' + insuranceForeign.toLocaleString() + '/year' + (country === 'uk' ? ' (NHS via IHS)' : '');
  document.getElementById('misc-bdt').textContent = formatBDT(miscBDT);
  document.getElementById('misc-usd').textContent = currency + ' ' + miscForeign.toLocaleString() + '/year (est)';
  document.getElementById('total-bdt').textContent = formatBDT(totalBDT);
  document.getElementById('total-usd').textContent = currency + ' ' + totalForeign.toLocaleString() + ' / year';

  const solvencyNeeded = formatBDT(totalBDT * 2);
  document.getElementById('scholarship-note').textContent = 'Bank Solvency Needed (2×): ' + solvencyNeeded + ' approx';
}

