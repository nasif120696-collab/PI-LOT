

// ══ Nav shrink handled in main scroll listener above ══

function mobileSearch(q) {
  const res = document.getElementById('mobile-search-results');
  if (!q || q.length < 2) { res.style.display = 'none'; return; }
  const filtered = searchIndex.filter(item =>
    item.label.toLowerCase().includes(q.toLowerCase()) || item.desc.toLowerCase().includes(q.toLowerCase())
  ).slice(0, 6);
  if (!filtered.length) { res.style.display = 'none'; return; }
  res.innerHTML = filtered.map(item => `
    <div onclick="closeMobileNav();searchGo('${item.id}','${item.testPanel||''}')"
      style="padding:0.5rem 0.7rem;cursor:pointer;border-radius:6px;background:rgba(255,255,255,0.06);margin-bottom:0.3rem;display:flex;align-items:center;gap:0.6rem;">
      <span style="font-size:1rem;">${item.icon}</span>
      <div>
        <div style="font-size:0.82rem;font-weight:800;color:var(--white);">${item.label}</div>
        <div style="font-size:0.7rem;color:var(--muted);">${item.desc}</div>
      </div>
    </div>`).join('');
  res.style.display = 'block';
}

// ── Nav scroll arrows ──
function scrollNav(amount) {
  const nav = document.getElementById('nav-links-container');
  if (nav) nav.scrollBy({ left: amount, behavior: 'smooth' });
}

// ── Test Prep Panel Switcher ──
function showTestPanel(id, btn) {
  document.querySelectorAll('.test-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.test-tab-btn').forEach(b => b.classList.remove('active'));
  const panel = document.getElementById('panel-' + id);
  if (panel) panel.classList.add('active');
  if (btn) btn.classList.add('active');
}

// ── Smart Search ──
const searchIndex = [
  { icon:'🎯', label:'Profile Matcher', desc:'Find your matched universities', id:'matcher' },
  { icon:'💰', label:'Cost Engine', desc:'Calculate study abroad costs in BDT', id:'cost-engine' },
  { icon:'🇺🇸', label:'USA Universities', desc:'MIT, Stanford, Georgia Tech and more', id:'usa-unis' },
  { icon:'🇨🇦', label:'Canada Universities', desc:'UofT, McGill, UBC and more', id:'canada-unis' },
  { icon:'🇩🇪', label:'Germany Universities', desc:'TUM, RWTH, Free tuition options', id:'germany-unis' },
  { icon:'🇬🇧', label:'UK Universities', desc:'Oxford, Manchester, Edinburgh', id:'uk-unis' },
  { icon:'🇦🇺', label:'Australia Universities', desc:'Melbourne, ANU, Monash', id:'australia-unis' },
  { icon:'🇯🇵', label:'Japan Universities', desc:'MEXT Scholarship, UTokyo, Osaka', id:'japan-unis' },
  { icon:'🇰🇷', label:'South Korea Universities', desc:'KAIST, SNU, GKS Scholarship', id:'korea-unis' },
  { icon:'🇨🇳', label:'China Universities', desc:'CSC Scholarship, Tsinghua, PKU', id:'china-unis' },
  { icon:'🇪🇺', label:'Europe Universities', desc:'TU Delft, ETH Zurich, KTH', id:'europe-unis' },
  { icon:'🏆', label:'Scholarships', desc:'Fully funded to partial scholarships', id:'scholarships' },
  { icon:'🔬', label:'Research-First Strategy', desc:'Low CGPA? Research publication guide', id:'research-first' },
  { icon:'📖', label:'IELTS Preparation', desc:'Target 7.0+, free resources, 6-month plan', id:'test-prep', testPanel:'ielts' },
  { icon:'📝', label:'TOEFL Preparation', desc:'Target 100+, free resources', id:'test-prep', testPanel:'toefl' },
  { icon:'📐', label:'GRE Preparation', desc:'Target 320+, Greg Mat free, 5-month plan', id:'test-prep', testPanel:'gre' },
  { icon:'💼', label:'GMAT Preparation', desc:'Target 680+, MBA test guide', id:'test-prep', testPanel:'gmat' },
  { icon:'🎓', label:'SAT Preparation', desc:'Target 1450+, Khan Academy free', id:'test-prep', testPanel:'sat' },
  { icon:'📋', label:'Document Checklist', desc:'USA, Canada, Germany, UK checklists', id:'checklist' },
  { icon:'📅', label:'365-Day Action Plan', desc:'Month-by-month roadmap', id:'calendar' },
  { icon:'💼', label:'Part-Time Jobs Abroad', desc:'Earning while studying', id:'jobs' },
  { icon:'✍️', label:'SOP Reviewer', desc:'AI-powered SOP feedback', id:'sop-reviewer' },
  { icon:'📧', label:'Cold Email Generator', desc:'Professor outreach email tool', id:'cold-email-gen' },
  { icon:'🎓', label:'Alumni Success Stories', desc:'Real BD student journeys', id:'alumni-stories' },
  { icon:'🔔', label:'Scholarship Deadlines', desc:'DAAD, Commonwealth, Erasmus timelines', id:'deadline-reminder' },
  { icon:'🗺️', label:'Cost Comparison Map', desc:'Country-by-country cost breakdown', id:'cost-map' },
  { icon:'🏦', label:'Bank Solvency Guide', desc:'How to prepare bank documents for visa', id:'bank-guide' },
  { icon:'💰', label:'DAAD Scholarship', desc:'Fully funded, Germany, EUR 861/mo', id:'scholarships' },
  { icon:'🇬🇧', label:'Commonwealth Scholarship', desc:'Fully funded, UK, BD quota available', id:'scholarships' },
  { icon:'🇯🇵', label:'MEXT Scholarship Japan', desc:'Japan govt scholarship, tuition + stipend', id:'japan-unis' },
  { icon:'🇰🇷', label:'GKS Scholarship Korea', desc:'Korea govt scholarship, fully funded', id:'korea-unis' },
  { icon:'🇨🇳', label:'CSC Scholarship China', desc:'Chinese govt scholarship, BD bilateral', id:'china-unis' },
  { icon:'🌍', label:'Erasmus Mundus', desc:'EUR 1400/mo + tuition, Europe', id:'scholarships' },
];

function initSearch() {
  const input = document.getElementById('search-input');
  const results = document.getElementById('search-results');
  if (!input || !results) return;
  input.addEventListener('input', () => {
    const q = input.value.trim().toLowerCase();
    if (!q) { results.classList.remove('open'); return; }
    const filtered = searchIndex.filter(item =>
      item.label.toLowerCase().includes(q) || item.desc.toLowerCase().includes(q)
    ).slice(0, 8);
    if (!filtered.length) {
      results.innerHTML = '<div class="search-no-results">No results — try "IELTS", "Germany", "scholarship"</div>';
    } else {
      results.innerHTML = filtered.map(item => `
        <div class="search-result-item" onclick="searchGo('${item.id}','${item.testPanel||''}')">
          <span class="search-result-icon">${item.icon}</span>
          <div><div class="search-result-label">${item.label}</div><div class="search-result-desc">${item.desc}</div></div>
        </div>`).join('');
    }
    results.classList.add('open');
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('#search-bar')) results.classList.remove('open');
  });
}
function searchGo(id, testPanel) {
  const el = document.getElementById(id);
  if (!el) return;
  const top = el.getBoundingClientRect().top + window.pageYOffset - 135;
  window.scrollTo({ top, behavior: 'smooth' });
  document.getElementById('search-results').classList.remove('open');
  document.getElementById('search-input').value = '';
  if (testPanel) {
    setTimeout(() => {
      const btn = document.querySelector('.test-tab-btn[onclick*="' + testPanel + '"]');
      showTestPanel(testPanel, btn);
    }, 600);
  }
}
// Search bar always visible (no hide on scroll)
// / key opens search
document.addEventListener('keydown', e => {
  if (e.key === '/' && !e.target.matches('input,textarea,select')) {
    e.preventDefault();
    document.getElementById('search-input')?.focus();
  }
  if (e.key === 'Escape') {
    document.getElementById('search-results')?.classList.remove('open');
    document.getElementById('search-input')?.blur();
  }
});
initSearch();
