// =====================================================
// NEW UX FEATURES JS
// =====================================================

// ── Reading Progress Bar ──
window.addEventListener('scroll', () => {
  const doc = document.documentElement;
  const scrolled = (window.scrollY / (doc.scrollHeight - doc.clientHeight)) * 100;
  document.getElementById('reading-bar').style.width = scrolled + '%';
  document.getElementById('back-top').classList.toggle('visible', window.scrollY > 400);
  document.querySelector('nav').classList.toggle('nav-scrolled', window.scrollY > 60);
  updateProgressTracker();
}, { passive: true });

// ── Progress Tracker ──
function updateProgressTracker() {
  const tracker = document.getElementById('progress-tracker');
  if (window.scrollY > 300) tracker.classList.add('visible');
  const sections = ['matcher','cost-engine','universities','scholarships','research-first','checklist','calendar'];
  const steps = document.querySelectorAll('.pt-step');
  sections.forEach((id, i) => {
    const el = document.getElementById(id);
    if (!el || !steps[i]) return;
    const rect = el.getBoundingClientRect();
    steps[i].classList.remove('active','done');
    if (rect.top <= 160) {
      steps[i].classList.add(rect.top <= -200 ? 'done' : 'active');
    }
  });
}

function scrollToSection(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ── Wizard ──



// Only show wizard on first visit
// ── PiLOT Wizard — clean isolated functions ──
function pilotWizNext(step) {
  document.querySelectorAll('.wizard-step').forEach(function(s) {
    s.classList.remove('wiz-active');
  });
  var el = document.getElementById('wz-' + step);
  if (el) el.classList.add('wiz-active');
}
function pilotCloseWizard() {
  var overlay = document.getElementById('wizard-overlay');
  overlay.classList.add('wiz-hiding');
  setTimeout(function() {
    overlay.style.display = 'none';
    overlay.classList.remove('wiz-hiding');
  }, 300);
  localStorage.setItem('sja_wizard_done', '1');
  showToast('🎓 PiLOT loaded! Press "/" for AI Advisor', 'success');
}
function pilotCloseWizardGoTo(selector) {
  pilotCloseWizard();
  setTimeout(function() {
    var el = document.querySelector(selector);
    if (el) el.scrollIntoView({ behavior:'smooth', block:'start' });
  }, 350);
}
// keep old names as aliases for safety
function wizNext(step) { pilotWizNext(step); }
function closeWizard() { pilotCloseWizard(); }
function closeWizardGoTo(s) { pilotCloseWizardGoTo(s); }
if (localStorage.getItem('sja_wizard_done')) {
  var wiz = document.getElementById('wizard-overlay');
  if (wiz) wiz.style.display = 'none';
}

// ── FAB Navigation ──
function toggleFab() {
  const menu = document.getElementById('fab-menu');
  const btn = document.getElementById('fab-main');
  menu.classList.toggle('open');
  btn.textContent = menu.classList.contains('open') ? '✕' : '☰';
}
function closeFab() {
  document.getElementById('fab-menu').classList.remove('open');
  document.getElementById('fab-main').textContent = '☰';
}
document.addEventListener('click', e => {
  if (!e.target.closest('.fab-container')) closeFab();
});

// ── Advisor Chat ──
const advisorKB = {
  'cgpa 2.8': '**CGPA 2.8 দিয়ে তোমার options:**\n\n🇩🇪 **Germany সবচেয়ে ভালো** — TUM, RWTH Aachen accept করে। Tuition প্রায় free (EUR 144/sem)!\n\n🇺🇸 **USA:** Arizona State, UMass — CGPA 2.8 accept করে। Research paper থাকলে MIT/GT-ও possible!\n\n🇨🇦 **Canada:** University of Manitoba (2.5+), Dalhousie — CGPA 2.8 ok.\n\n**Key tip:** 1টা publication থাকলে যেকোনো CGPA দিয়ে top university-তে chance আছে। Research-First section দেখো! 🔬',
  'germany cost': '🇩🇪 **Germany Annual Cost:**\n\n📚 Tuition: EUR 144-300/semester (≈ ৳17-36K) — প্রায় FREE!\n\n🏠 Living: EUR 850-1,100/month (≈ ৳1-1.3 Lac/mo)\n\n🏥 Health Insurance: EUR 110/mo (mandatory, covered in blocked account)\n\n**Total Annual: ৳12-15 Lac** (blocked account: ৳14.3 Lac required)\n\n✅ Germany = cheapest quality education globally for Bangladeshi students!',
  'fully funded': '🏆 **Best Fully Funded Options for BD Students:**\n\n1. **DAAD (Germany):** EUR 861/mo + tuition + flights. Min CGPA 2.8. Deadline: Oct/Nov\n2. **Commonwealth Masters (UK):** Full tuition + GBP 1,347/mo. BD quota exists! Dec 15\n3. **Erasmus Mundus:** EUR 1,400/mo + full tuition. Europe. Jan-Feb\n4. **Vanier CGS (Canada PhD):** CAD 50K/yr. Need 3.5+\n5. **MIT/GT RA/TA:** Full tuition + USD 2,500-3,500/mo stipend via professor\n\n**Fastest win:** DAAD for Germany + Email professors for RA in USA! 🎯',
  'cold email': '📧 **Cold Email Formula (25%+ reply rate):**\n\n**Subject:** Prospective PhD Student — [Your Research Topic] Inquiry\n\n**Body (150 words max):**\n1. পরিচয় + পড়লাম তোমার "[specific paper title]" paper\n2. আমার similar কাজ: [your research/project]\n3. Request: 15-min video call\n\n**Tips:**\n• Email করো Tuesday-Thursday, সকাল 9am (professor-এর timezone)\n• 30-50 professors target করো\n• প্রতিটা email customize করো\n• 2 সপ্তাহ পর একবার follow-up\n\nResearch-First section-এ full template আছে! 🔬',
  'no ielts': '📖 **IELTS ছাড়া options:**\n\n✅ **Germany (English programs):** অনেক programs IELTS ছাড়া accept করে — University of Stuttgart, FU Berlin\n\n✅ **Canada:** কিছু universities Duolingo English Test accept করে\n\n✅ **USA:** TOEFL alternative হিসেবে accepted\n\n⚠️ **UK:** IELTS UKVI mandatory (regular IELTS-ও accepted কোনো কোনো uni-তে)\n\n**আমার suggestion:** 5-6 months IELTS prep করো। 7.0+ হলে সব door খোলে। Cambridge Practice Tests 14-18 use করো!',
  'canada pr': '🇨🇦 **Canada PR Fastest Routes:**\n\n🥇 **Atlantic Immigration Pilot** (Dalhousie/Saint Mary\'s): 1-2 বছরে PR! Study + work করলেই eligible\n\n🥈 **Manitoba PNP** (Univ. of Manitoba): Graduate + 1 year work = PR nominee\n\n🥉 **BC PNP Tech** (UBC): Tech field হলে 6-12 months\n\n**PGWP:** যেকোনো Canadian degree-র পর 1-3 years open work permit\n\n**Express Entry CRS:** Canadian degree = +15 points bonus!\n\n💡 Atlantic route সবচেয়ে fast। Checklist section-এ details আছে!',
  'ielts score': '📊 **IELTS Score Requirements by Country:**\n\n🇺🇸 USA: 6.5 minimum (7.0+ preferred)\n🇨🇦 Canada: 6.5 minimum (SDS: 6.0+)\n🇩🇪 Germany: 6.5 (English programs)\n🇬🇧 UK: 6.5-7.5 (UKVI IELTS required!)\n\n**Tips to score 7.0+:**\n• Cambridge IELTS 14-18 (official practice)\n• Writing Task 2: 250+ words, 4 paragraphs\n• Speaking: Record yourself daily\n• Reading: Time yourself strictly\n\nPrep timeline: 5-6 months for 7.0. IELTS Prep section দেখো!',
  'bank solvency': '🏦 **Bank Solvency Guide:**\n\n🇺🇸 USA (unfunded MS): ৳60-90 Lac needed\n🇨🇦 Canada: ৳35-45 Lac (or GIC + letter)\n🇩🇪 Germany: ৳15 Lac (blocked account)\n🇬🇧 UK: ৳50-70 Lac (28-day rule!)\n\n**Rules:**\n• 3+ months আগে থেকে maintain করো\n• Lump sum deposit করো না — detected হয়\n• FDR (Fixed Deposit) সবচেয়ে safe option\n• Parents/guardian co-sponsor করতে পারবে\n• Germany: Fintiba blocked account best option',
  'research paper': '🔬 **Research Paper কীভাবে লিখবো?**\n\n**Step 1:** Thesis supervisor-এর সাথে কথা বলো — co-author হওয়ার chance নাও\n\n**Step 2:** Target journals:\n• IEEE Access (fast review, open access)\n• MDPI journals (reliable, indexed)\n• arXiv preprint (instant visibility)\n\n**Step 3:** Bangladesh-specific problem solve করো — local data = unique contribution\n\n**Step 4:** ICCIT/ICECE conference → journal extension\n\n**Timeline:** 4th year শেষের আগে minimum 1 submitted paper\n\n**Pro tip:** Even 2nd/3rd author counts! Research-First section full guide আছে।',
};

function toggleAdvisor() {
  const panel = document.getElementById('advisor-panel');
  const isOpen = panel.classList.contains('open');
  if (isOpen) {
    panel.style.opacity = '0';
    panel.style.transform = 'translateY(10px) scale(0.97)';
    setTimeout(() => { panel.classList.remove('open'); panel.style.cssText = ''; }, 240);
  } else {
    panel.style.display = 'block';
    panel.style.opacity = '0';
    panel.style.transform = 'translateY(10px) scale(0.97)';
    requestAnimationFrame(() => requestAnimationFrame(() => {
      panel.classList.add('open');
      panel.style.opacity = '1';
      panel.style.transform = 'translateY(0) scale(1)';
    }));
  }
}

function askAdvisor(question, imageBase64) {
  const msgs = document.getElementById('advisor-msgs');
  // Build user bubble — show image preview if provided
  let userBubble = '';
  if (imageBase64) {
    userBubble = `<div class="msg-user"><div style="margin-bottom:0.4rem;">${question || '📎 Document uploaded'}</div><img src="${imageBase64}" style="max-width:100%;max-height:160px;object-fit:contain;border-radius:8px;border:1px solid rgba(255,255,255,0.12);" alt="Uploaded"></div>`;
  } else {
    userBubble = `<div class="msg-user">${question}</div>`;
  }
  msgs.innerHTML += userBubble;
  // Typing dots
  const typing = document.createElement('div');
  typing.className = 'msg-bot';
  typing.id = 'typing-indicator';
  typing.innerHTML = '<span style="display:inline-flex;gap:4px;align-items:center;">' +
    '<span style="width:6px;height:6px;border-radius:50%;background:var(--emerald-light);animation:typingDot 1s ease infinite 0s;display:inline-block;"></span>' +
    '<span style="width:6px;height:6px;border-radius:50%;background:var(--emerald-light);animation:typingDot 1s ease infinite 0.2s;display:inline-block;"></span>' +
    '<span style="width:6px;height:6px;border-radius:50%;background:var(--emerald-light);animation:typingDot 1s ease infinite 0.4s;display:inline-block;"></span>' +
    '</span>';
  msgs.appendChild(typing);
  msgs.scrollTop = msgs.scrollHeight;
  setTimeout(() => {
    const indicator = document.getElementById('typing-indicator');
    if (indicator) indicator.remove();
    let response;
    if (imageBase64 && !question) {
      response = '📸 **Document received!**\n\nআমি তোমার document দেখতে পাচ্ছি। এটা কি তোমার **transcript, admission letter, নাকি scholarship document**?\n\nসেটা বললে আমি specific advice দিতে পারবো!\n\n**তুমি জিজ্ঞেস করতে পারো:**\n• এই transcript দিয়ে কোথায় apply করবো?\n• এই letter-এর পরের steps কী?\n• Document-এ কোনো issue আছে?';
    } else {
      response = getAdvisorResponse(question || '');
    }
    const formatted = response.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
    msgs.innerHTML += '<div class="msg-bot" style="animation:msgIn 0.3s ease;">' + formatted + '</div>';
    msgs.scrollTop = msgs.scrollHeight;
  }, 800);
}

function sendAdvisor() {
  const input = document.getElementById('advisor-input');
  const q = input.value.trim();
  const fileInput = document.getElementById('advisor-img-input');
  const file = fileInput && fileInput.files[0];
  if (!q && !file) return;
  if (file) {
    const reader = new FileReader();
    reader.onload = function(e) {
      askAdvisor(q, e.target.result);
      input.value = '';
      fileInput.value = '';
      // Clear preview
      const prev = document.getElementById('img-preview-bar');
      if (prev) prev.remove();
    };
    reader.readAsDataURL(file);
  } else {
    askAdvisor(q);
    input.value = '';
  }
}

function handleAdvisorImagePreview(input) {
  const file = input.files[0];
  if (!file) return;
  // Remove any existing preview
  const existing = document.getElementById('img-preview-bar');
  if (existing) existing.remove();
  const reader = new FileReader();
  reader.onload = function(e) {
    const row = document.querySelector('.advisor-input-row');
    const preview = document.createElement('div');
    preview.id = 'img-preview-bar';
    preview.className = 'advisor-img-preview';
    const isImage = file.type.startsWith('image/');
    preview.innerHTML = (isImage
      ? `<img src="${e.target.result}" alt="preview">`
      : `<span style="font-size:1.3rem;">📄</span>`) +
      `<span>${file.name}</span>` +
      `<button onclick="clearAdvisorImage()" title="Remove">✕</button>`;
    row.parentNode.insertBefore(preview, row);
  };
  reader.readAsDataURL(file);
}

function clearAdvisorImage() {
  const fileInput = document.getElementById('advisor-img-input');
  if (fileInput) fileInput.value = '';
  const prev = document.getElementById('img-preview-bar');
  if (prev) prev.remove();
}

function getAdvisorResponse(question) {
  const q = question.toLowerCase();
  for (const [key, val] of Object.entries(advisorKB)) {
    if (key.split(' ').some(k => q.includes(k))) return val;
  }
  // Contextual fallback
  if (q.includes('usa') || q.includes('america')) return '🇺🇸 **USA Tips:** Apply Oct-Dec. F-1 visa. GRE optional (most). IELTS 6.5+. For PhD: email professors first! RA/TA = full funding. OPT/STEM OPT = 3 yrs work after graduation. Cost Engine-এ USA cost দেখো!';
  if (q.includes('uk') || q.includes('england')) return '🇬🇧 **UK Tips:** 1-year Masters (faster!). UKVI IELTS required. Graduate Route = 2 yrs work after. Commonwealth Scholarship = fully funded for BD citizens. Birmingham/Manchester best BD community!';
  if (q.includes('visa') || q.includes('embassy')) return '🛂 **Visa Tips:** Embassy Masterclass section দেখো! Key: bank solvency 3+ months, ties to Bangladesh, clear study plan. Germany = APS certificate mandatory. UK = UKVI IELTS. USA = F-1 with I-20. Canada = usually no interview!';
  if (q.includes('sop') || q.includes('statement')) return '📝 **SOP Writing Tips:**\n• 800-1000 words, no fluff\n• CGPA কম? Acknowledge করো + pivot করো research-এ\n• Specific professor/research mention করো\n• "Why this university" — specific হও\n• Upward GPA trend থাকলে mention করো\n• Avoid generic openers ("Since childhood I dreamed...")\nResearch-First section-এ full SOP guide!';
  if (q.includes('gre')) return '📐 **GRE Guide:**\n• 2025-এ বেশিরভাগ uni optional করেছে\n• BUET/CS background = Q165+ possible\n• Target: V155+ Q165+ AWA 4.0+ (Total 320+)\n• Resources: Magoosh (USD 149), Greg Mat (YouTube free), ETS Official Tests\n• Prep time: 4-5 months\n• 320+ score application significantly strengthen করে!';
  return '🤔 দুর্দান্ত প্রশ্ন! এই topic-এ আমাদের বিস্তারিত guide আছে। উপরে relevant section দেখো, অথবা আরো specific করে জিজ্ঞেস করো। যেমন: "Germany-তে CGPA 2.9 দিয়ে apply করতে পারবো?" 😊\n\n**Quick sections:**\n• Profile Matcher → তোমার exact match\n• Research-First → Low CGPA strategy\n• Checklist → Document guide\n• Scholarships → Funding options';
}

// ── Toast Notifications ──
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = message;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}

// ── Compare Tool ──
let compareList = [];
function addToCompare(uniName, uniData) {
  if (compareList.length >= 3) { showToast('⚠️ Maximum 3 universities compare করা যাবে', 'info'); return; }
  if (compareList.find(u => u.name === uniName)) { showToast('ℹ️ Already added!', 'info'); return; }
  compareList.push({ name: uniName, ...uniData });
  updateCompareBar();
  showToast(`✅ ${uniName} added to compare`, 'success');
}
function updateCompareBar() {
  const bar = document.querySelector('.compare-bar');
  const slots = document.querySelector('.compare-slots');
  if (compareList.length > 0) {
    bar.classList.add('visible');
    slots.innerHTML = compareList.map((u, i) => `<div class="compare-slot filled">${u.name} <span onclick="removeCompare(${i})" style="cursor:pointer;margin-left:0.3rem;color:var(--danger);">✕</span></div>`).join('');
  } else { bar.classList.remove('visible'); }
}
function removeCompare(i) {
  compareList.splice(i, 1);
  updateCompareBar();
}
function clearCompare() {
  compareList = [];
  updateCompareBar();
}
function openCompare() {
  if (compareList.length < 2) { showToast('⚠️ কমপক্ষে 2টা university select করো', 'info'); return; }
  const rows = [
    { label:'Country', key: 'country' },
    { label:'QS Rank', key: 'rank' },
    { label:'Min CGPA', key: 'minCGPA' },
    { label:'Annual Cost', key: 'costStr' },
    { label:'Funding', key: 'fundingStr' },
    { label:'Post-study Work', key: 'pr' },
    { label:'Scholarships', key: 'scholarshipsStr' },
    { label:'Best For', key: 'notes' },
  ];
  const thead = `<tr><th>Criteria</th>${compareList.map(u => `<th>${u.name}</th>`).join('')}</tr>`;
  const tbody = rows.map(r => `<tr><td>${r.label}</td>${compareList.map(u => `<td>${u[r.key] || '—'}</td>`).join('')}</tr>`).join('');
  document.getElementById('compare-table-content').innerHTML = `<table class="compare-table"><thead>${thead}</thead><tbody>${tbody}</tbody></table>`;
  document.getElementById('compare-modal').classList.add('open');
}
function closeCompare() {
  document.getElementById('compare-modal').classList.remove('open');
}

// Populate compare data from matcher results
function addMatchedToCompare(uniObj) {
  const data = {
    country: uniObj.country,
    rank: uniObj.rank,
    minCGPA: uniObj.minCGPA,
    costStr: uniObj.currency + ' ' + uniObj.cost.toLocaleString() + '/yr',
    fundingStr: uniObj.funding ? '✅ Yes (RA/TA/Fellowship)' : '❌ Self-funded',
    pr: uniObj.pr,
    scholarshipsStr: uniObj.scholarships.join(', '),
    notes: uniObj.notes
  };
  addToCompare(uniObj.name, data);
}

// Patch runMatcher to inject compare buttons (see override below)


// ── Theme Toggle ──
function toggleTheme() {
  const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
  document.documentElement.setAttribute('data-theme', isDark ? 'light' : 'dark');
  localStorage.setItem('pilot_theme', isDark ? 'light' : 'dark');
  const label = document.getElementById('mobile-theme-label');
  if (label) label.textContent = isDark ? 'Light' : 'Dark';
}
// Apply saved theme on load
(function() {
  const saved = localStorage.getItem('pilot_theme') || 'dark';
  document.documentElement.setAttribute('data-theme', saved);
  const label = document.getElementById('mobile-theme-label');
  if (label) label.textContent = saved === 'light' ? 'Light' : 'Dark';
})();

// ── Mobile Nav ──
function toggleMobileNav() {
  const btn = document.getElementById('hamburger-btn');
  const drawer = document.getElementById('mobile-nav-drawer');
  const overlay = document.getElementById('mobile-nav-overlay');
  const isOpen = drawer.classList.contains('open');
  if (isOpen) {
    closeMobileNav();
  } else {
    drawer.classList.add('open');
    overlay.classList.add('open');
    btn && btn.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
}
function closeMobileNav() {
  const btn = document.getElementById('hamburger-btn');
  const drawer = document.getElementById('mobile-nav-drawer');
  const overlay = document.getElementById('mobile-nav-overlay');
  drawer.classList.remove('open');
  overlay.classList.remove('open');
  btn && btn.classList.remove('open');
  document.body.style.overflow = '';
}

// ── Smooth scroll offset fix ──
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const offset = 120;
      const top = target.getBoundingClientRect().top + window.pageYOffset - offset;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});

// ── Keyboard shortcut hint ──
document.addEventListener('keydown', e => {
  if (e.key === '/' && !e.target.matches('input,textarea,select')) {
    e.preventDefault();
    document.getElementById('advisor-input').focus();
    document.getElementById('advisor-panel').classList.add('open');
  }
  if (e.key === 'Escape') {
    closeWizard();
    closeCompare();
    const advisorPanel = document.getElementById('advisor-panel');
    if (advisorPanel && advisorPanel.classList.contains('open')) toggleAdvisor();
    closeFab();
    closeMobileNav();
  }
});

// ── Show keyboard shortcut toast on load ──
setTimeout(() => {
  if (!localStorage.getItem('sja_wizard_done')) return;
  showToast('💡 Tip: Press "/" to open AI Advisor anytime', 'info');
}, 2000);

// ── Patch runMatcher to inject compare buttons ──
const origRunMatcher = window.runMatcher;
window.runMatcher = function() {
  origRunMatcher();
  // After results render, inject compare buttons into matched uni cards
  setTimeout(() => {
    document.querySelectorAll('.matched-uni-card').forEach((card, i) => {
      if (card.querySelector('.add-compare-btn')) return;
      const btn = document.createElement('button');
      btn.className = 'add-compare-btn';
      btn.style.cssText = 'margin-top:0.7rem;background:rgba(96,165,250,0.1);border:1px solid rgba(96,165,250,0.3);color:var(--sky);padding:0.3rem 0.8rem;border-radius:6px;font-size:0.75rem;font-weight:800;cursor:pointer;font-family:Nunito,sans-serif;';
      btn.textContent = '+ Compare';
      btn.onclick = () => {
        const name = card.querySelector('.muc-name')?.textContent;
        const country = card.querySelector('.muc-country')?.textContent;
        const rank = card.querySelector('.muc-country')?.textContent.split('·')[1]?.trim() || '';
        addToCompare(name, { country, rank, minCGPA:'—', costStr:'See Cost Engine', fundingStr: card.querySelector('.muc-tag.funded') ? '✅ Available' : '—', pr:'—', scholarshipsStr:'See Scholarships', notes: card.querySelectorAll('.muc-tag')[2]?.textContent || '—' });
      };
      card.querySelector('.muc-tags')?.after(btn);
    });
  }, 200);
};


<!-- ── Compare Bar ── -->
<div class="compare-bar" id="compare-bar">
  <span class="compare-bar-label">🔍 Compare:</span>
  <div class="compare-slots"></div>
  <button class="compare-go-btn" onclick="openCompare()">Compare Now</button>
  <button class="compare-clear" onclick="clearCompare()" title="Clear all">✕</button>
</div>


