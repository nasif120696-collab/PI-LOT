// ===== PROFILE MATCHER ENGINE =====
const uniDatabase = [
  // USA
  { name:"MIT", country:"🇺🇸 USA", rank:"QS #1", minCGPA:2.8, idealCGPA:3.7, subjects:["cs-it","eee","mech-civil","physics-math","life-science","chem-bio-eng"], degrees:["masters","phd"], countries:["usa","any"], funding:true, cost:59000, currency:"USD", scholarships:["MIT RA/TA (Fully Funded PhD)"], pr:"OPT/STEM OPT", notes:"Publication required for low CGPA" },
  { name:"Stanford University", country:"🇺🇸 USA", rank:"QS #3", minCGPA:3.0, idealCGPA:3.8, subjects:["cs-it","eee","mech-civil","business-mba","physics-math","life-science"], degrees:["masters","phd","mba"], countries:["usa","any"], funding:true, cost:62000, currency:"USD", scholarships:["Knight-Hennessy (Full)","RA/TA"], pr:"OPT/STEM OPT", notes:"LORs from professors critical" },
  { name:"Georgia Tech", country:"🇺🇸 USA", rank:"QS #88", minCGPA:2.9, idealCGPA:3.3, subjects:["cs-it","eee","mech-civil","physics-math"], degrees:["masters","phd"], countries:["usa","any"], funding:true, cost:33000, currency:"USD", scholarships:["President's Fellowship","RA/TA"], pr:"OPT/STEM OPT (3yr)", notes:"Strong BD alumni network" },
  { name:"Univ. of Texas Austin", country:"🇺🇸 USA", rank:"QS #54", minCGPA:3.0, idealCGPA:3.3, subjects:["cs-it","eee","mech-civil","physics-math","economics","business-mba"], degrees:["masters","phd","mba"], countries:["usa","any"], funding:true, cost:22000, currency:"USD", scholarships:["Graduate RA","Merit Scholarship"], pr:"OPT/STEM OPT", notes:"Email Prof before applying" },
  { name:"Arizona State Univ.", country:"🇺🇸 USA", rank:"QS #216", minCGPA:2.5, idealCGPA:2.75, subjects:["cs-it","eee","mech-civil","social-arts","business-mba","life-science","other"], degrees:["masters","bachelors","mba"], countries:["usa","any"], funding:false, cost:28000, currency:"USD", scholarships:["Global Launch Grant"], pr:"OPT/STEM OPT (3yr)", notes:"Accepts CGPA 2.5+. Best for low CGPA" },
  { name:"Univ. of Cincinnati", country:"🇺🇸 USA", rank:"QS ~550", minCGPA:2.5, idealCGPA:2.8, subjects:["cs-it","eee","mech-civil","chem-bio-eng","architecture"], degrees:["masters","phd"], countries:["usa","any"], funding:true, cost:26000, currency:"USD", scholarships:["TA Positions","Merit USD 5K"], pr:"OPT + Co-op", notes:"Co-op: paid USD 15-20/hr" },
  { name:"Univ. of Massachusetts Amherst", country:"🇺🇸 USA", rank:"QS ~180", minCGPA:2.8, idealCGPA:3.2, subjects:["cs-it","eee","life-science","physics-math"], degrees:["masters","phd"], countries:["usa","any"], funding:true, cost:31000, currency:"USD", scholarships:["RA/TA Positions"], pr:"OPT/STEM OPT", notes:"Strong research groups in CS/ML" },
  // CANADA
  { name:"Univ. of Toronto", country:"🇨🇦 Canada", rank:"QS #25", minCGPA:3.0, idealCGPA:3.5, subjects:["cs-it","eee","mech-civil","life-science","business-mba","economics","physics-math","social-arts"], degrees:["masters","phd","mba"], countries:["canada","any"], funding:true, cost:30000, currency:"CAD", scholarships:["Vanier CGS (Full)","OGS"], pr:"Express Entry / PGWP", notes:"Faculty match crucial for PhD" },
  { name:"McGill University", country:"🇨🇦 Canada", rank:"QS #46", minCGPA:3.0, idealCGPA:3.2, subjects:["cs-it","eee","life-science","physics-math","social-arts","economics"], degrees:["masters","phd"], countries:["canada","any"], funding:true, cost:25000, currency:"CAD", scholarships:["FRQNT Fellowship"], pr:"PGWP + Express Entry", notes:"Montreal — low living cost" },
  { name:"Univ. of British Columbia", country:"🇨🇦 Canada", rank:"QS #38", minCGPA:3.0, idealCGPA:3.3, subjects:["cs-it","eee","life-science","business-mba","social-arts","mech-civil","economics"], degrees:["masters","phd","mba"], countries:["canada","any"], funding:true, cost:13000, currency:"CAD", scholarships:["4YF Fellowship (Full)","ITA"], pr:"BC PNP (strong)", notes:"Low tuition for intl grad students" },
  { name:"Univ. of Waterloo", country:"🇨🇦 Canada", rank:"QS #154", minCGPA:3.0, idealCGPA:3.0, subjects:["cs-it","eee","mech-civil","physics-math","chem-bio-eng"], degrees:["masters","phd"], countries:["canada","any"], funding:true, cost:22000, currency:"CAD", scholarships:["President's Award","RA"], pr:"PGWP + Ontario Express Entry", notes:"Co-op: USD 20-40/hr at Google/Meta" },
  { name:"Univ. of Manitoba", country:"🇨🇦 Canada", rank:"QS ~700", minCGPA:2.5, idealCGPA:2.7, subjects:["cs-it","eee","mech-civil","life-science","social-arts","physics-math","other"], degrees:["masters","phd"], countries:["canada","any"], funding:true, cost:14000, currency:"CAD", scholarships:["GETS Scholarship","Grad RA"], pr:"Manitoba PNP (fast)", notes:"Largest BD community in Canada academia" },
  { name:"Dalhousie University", country:"🇨🇦 Canada", rank:"QS ~650", minCGPA:3.0, idealCGPA:3.0, subjects:["cs-it","eee","life-science","mech-civil","social-arts"], degrees:["masters","phd"], countries:["canada","any"], funding:true, cost:18000, currency:"CAD", scholarships:["Atlantic Intl Scholarship","Killam"], pr:"Atlantic Immigration Pilot (FASTEST)", notes:"PR in 1-2 years post-graduation" },
  { name:"Univ. of Calgary", country:"🇨🇦 Canada", rank:"QS ~235", minCGPA:3.0, idealCGPA:3.2, subjects:["cs-it","eee","mech-civil","business-mba","economics","life-science"], degrees:["masters","phd","mba"], countries:["canada","any"], funding:true, cost:19000, currency:"CAD", scholarships:["Eyes High Scholarship"], pr:"Alberta PNP + PGWP", notes:"Alberta has strong tech/energy sector" },
  // GERMANY
  { name:"TU Munich (TUM)", country:"🇩🇪 Germany", rank:"QS #37", minCGPA:2.5, idealCGPA:3.0, subjects:["cs-it","eee","mech-civil","chem-bio-eng","architecture","physics-math","life-science"], degrees:["masters","phd"], countries:["germany","any"], funding:false, cost:400, currency:"EUR", scholarships:["DAAD (Full)","Deutschlandstipendium"], pr:"18-month job seeker visa", notes:"Tuition ≈ FREE (EUR 144/sem). APS needed." },
  { name:"RWTH Aachen", country:"🇩🇪 Germany", rank:"QS #106", minCGPA:2.7, idealCGPA:3.0, subjects:["cs-it","eee","mech-civil","chem-bio-eng","physics-math"], degrees:["masters","phd"], countries:["germany","any"], funding:false, cost:300, currency:"EUR", scholarships:["DAAD","RWTH Excellence"], pr:"Job seeker visa 18 months", notes:"BMW/Siemens/VW recruiter visits" },
  { name:"Heidelberg University", country:"🇩🇪 Germany", rank:"QS #87", minCGPA:3.0, idealCGPA:3.2, subjects:["life-science","physics-math","social-arts","chem-bio-eng","economics"], degrees:["masters","phd"], countries:["germany","any"], funding:false, cost:1500, currency:"EUR", scholarships:["Erasmus Mundus (Full)","DAAD"], pr:"Job seeker visa 18 months", notes:"Erasmus Mundus: Best for life sciences" },
  { name:"FU Berlin", country:"🇩🇪 Germany", rank:"QS #110", minCGPA:2.5, idealCGPA:2.8, subjects:["social-arts","economics","life-science","physics-math","cs-it"], degrees:["masters","phd"], countries:["germany","any"], funding:false, cost:600, currency:"EUR", scholarships:["DAAD","Friedrich Ebert Stiftung"], pr:"Job seeker visa 18 months", notes:"Berlin — most affordable German city" },
  { name:"KIT (Karlsruhe)", country:"🇩🇪 Germany", rank:"QS ~131", minCGPA:2.7, idealCGPA:3.0, subjects:["cs-it","eee","mech-civil","physics-math","chem-bio-eng"], degrees:["masters","phd"], countries:["germany","any"], funding:false, cost:300, currency:"EUR", scholarships:["DAAD","KIT Scholarship"], pr:"Job seeker visa 18 months", notes:"Strong engineering + tech industry links" },
  { name:"Univ. of Stuttgart", country:"🇩🇪 Germany", rank:"QS ~300", minCGPA:2.5, idealCGPA:2.8, subjects:["mech-civil","eee","cs-it","chem-bio-eng","architecture"], degrees:["masters","phd"], countries:["germany","any"], funding:false, cost:300, currency:"EUR", scholarships:["DAAD","Baden-Württemberg Stipendium"], pr:"Job seeker visa 18 months", notes:"Mercedes-Benz/Bosch recruitment campus" },
  // UK
  { name:"Univ. of Oxford", country:"🇬🇧 UK", rank:"QS #4", minCGPA:3.5, idealCGPA:3.8, subjects:["cs-it","life-science","social-arts","economics","physics-math","business-mba"], degrees:["masters","phd","mba"], countries:["uk","any"], funding:true, cost:34000, currency:"GBP", scholarships:["Clarendon (Full)","Rhodes (Full)","Commonwealth"], pr:"Graduate Route 2yr", notes:"Rhodes: leadership weighted over GPA" },
  { name:"Univ. of Edinburgh", country:"🇬🇧 UK", rank:"QS #27", minCGPA:3.0, idealCGPA:3.3, subjects:["cs-it","eee","life-science","social-arts","economics","architecture"], degrees:["masters","phd"], countries:["uk","any"], funding:true, cost:27000, currency:"GBP", scholarships:["Edinburgh Global Scholarship"], pr:"Graduate Route 2yr", notes:"Scotland: lower cost vs London" },
  { name:"Univ. of Manchester", country:"🇬🇧 UK", rank:"QS #34", minCGPA:2.8, idealCGPA:3.0, subjects:["cs-it","eee","life-science","economics","business-mba","social-arts"], degrees:["masters","phd","mba"], countries:["uk","any"], funding:true, cost:24000, currency:"GBP", scholarships:["Alliance Manchester Award","CSC"], pr:"Graduate Route 2yr", notes:"Largest BD community in UK outside London" },
  { name:"Univ. of Birmingham", country:"🇬🇧 UK", rank:"QS #93", minCGPA:2.8, idealCGPA:2.8, subjects:["cs-it","eee","life-science","business-mba","social-arts","mech-civil","economics"], degrees:["masters","phd","mba"], countries:["uk","any"], funding:false, cost:22000, currency:"GBP", scholarships:["Birmingham International Award","Commonwealth Masters (Full)"], pr:"Graduate Route 2yr", notes:"2:2 accepted. Best value Russell Group" },
  { name:"Univ. of Leeds", country:"🇬🇧 UK", rank:"QS ~92", minCGPA:2.8, idealCGPA:3.0, subjects:["cs-it","eee","social-arts","economics","architecture","business-mba","life-science"], degrees:["masters","phd"], countries:["uk","any"], funding:false, cost:20000, currency:"GBP", scholarships:["Leeds Intl Scholarship (30%)"], pr:"Graduate Route 2yr", notes:"Strong social science + media programs" }
];

const scholarshipDB = [
  { name:"DAAD Scholarship", type:"full", country:"Germany", minCGPA:2.8, amount:"EUR 861/mo + fees + flights", bdt:"৳10.3 Lac/yr", deadline:"Oct/Nov", subjects:"all", forDegrees:["masters","phd"] },
  { name:"Vanier Canada Graduate Scholarship", type:"full", country:"Canada", minCGPA:3.5, amount:"CAD 50,000/yr stipend + tuition", bdt:"৳41 Lac/yr", deadline:"Nov 1", subjects:"all", forDegrees:["phd"] },
  { name:"Commonwealth Masters Scholarship", type:"full", country:"UK", minCGPA:3.0, amount:"Full tuition + GBP 1,347/mo + flights", bdt:"৳22 Lac/yr", deadline:"Dec 15", subjects:"all", forDegrees:["masters"] },
  { name:"Erasmus Mundus Joint Masters", type:"full", country:"Europe", minCGPA:3.0, amount:"EUR 1,400/mo + full tuition + travel", bdt:"৳16.8 Lac/yr", deadline:"Jan–Feb", subjects:"all", forDegrees:["masters"] },
  { name:"Rhodes Scholarship (Oxford)", type:"full", country:"UK", minCGPA:3.5, amount:"GBP 18,000/yr + all fees", bdt:"৳25 Lac/yr", deadline:"Oct 1", subjects:"all", forDegrees:["masters","phd"] },
  { name:"MIT/Stanford/GT RA or TA", type:"full", country:"USA", minCGPA:2.8, amount:"Full tuition + USD 2,500-3,500/mo", bdt:"৳44 Lac/yr equiv", deadline:"Dec 15", subjects:["cs-it","eee","mech-civil","physics-math","life-science","chem-bio-eng"], forDegrees:["phd","masters"] },
  { name:"Ontario Graduate Scholarship (OGS)", type:"partial", country:"Canada", minCGPA:3.2, amount:"CAD 10,000–15,000/yr", bdt:"৳8.2–12.3 Lac", deadline:"Varies by univ", subjects:"all", forDegrees:["masters","phd"] },
  { name:"Deutschlandstipendium", type:"partial", country:"Germany", minCGPA:2.7, amount:"EUR 300/month", bdt:"৳3.6 Lac/yr", deadline:"Varies (univ)", subjects:"all", forDegrees:["masters","phd"] },
  { name:"Birmingham International Award", type:"partial", country:"UK", minCGPA:2.8, amount:"GBP 2,000–5,000 tuition reduction", bdt:"৳2.8–7 Lac", deadline:"Rolling", subjects:"all", forDegrees:["masters"] },
  { name:"UBC 4YF Fellowship", type:"full", country:"Canada", minCGPA:3.0, amount:"Full tuition + CAD 18,200/yr", bdt:"৳14.9 Lac/yr", deadline:"Jan 15", subjects:"all", forDegrees:["phd"] },
  { name:"Atlantic Immigration Scholarship", type:"full", country:"Canada", minCGPA:3.0, amount:"Full tuition waiver + stipend", bdt:"৳14+ Lac/yr", deadline:"Rolling", subjects:"all", forDegrees:["masters","phd"] },
  { name:"ASU Global Launch Grant", type:"partial", country:"USA", minCGPA:2.5, amount:"USD 3,000–6,000/yr reduction", bdt:"৳3.3–6.6 Lac", deadline:"Rolling", subjects:"all", forDegrees:["masters","mba"] }
];

const exchangeApprox = { USD: 110, CAD: 82, EUR: 120, GBP: 140 };

function runMatcher() {
  const year = document.getElementById('m-year').value;
  const uniType = document.getElementById('m-uni-type').value;
  const cgpaRange = document.getElementById('m-cgpa').value;
  const subject = document.getElementById('m-subject').value;
  const country = document.getElementById('m-country').value;
  const degree = document.getElementById('m-degree').value;
  const ielts = document.getElementById('m-ielts').value;
  const gre = document.getElementById('m-gre').value;
  const research = document.getElementById('m-research').value;
  const budget = document.getElementById('m-budget').value;
  const priority = document.getElementById('m-priority').value;

  if (!cgpaRange || !subject || !degree) {
    document.getElementById('matcher-results').innerHTML = `
      <div class="profile-warning">⚠️ Please fill in at least: <strong>CGPA, Subject/Department, and Target Degree</strong> to get matched results.</div>`;
    return;
  }

  // Parse CGPA range to numeric
  const cgpaMap = { 'below2.5': 2.3, '2.5-2.9': 2.7, '3.0-3.3': 3.15, '3.4-3.6': 3.5, '3.7+': 3.8 };
  const cgpa = cgpaMap[cgpaRange] || 3.0;

  // Filter and score universities
  let matched = uniDatabase.filter(u => {
    const countryMatch = country === '' || country === 'any' || u.countries.includes(country) || u.countries.includes('any');
    const degreeMatch = degree === '' || u.degrees.includes(degree);
    const subjectMatch = u.subjects.includes(subject) || u.subjects.includes('all');
    const cgpaFeasible = cgpa >= (u.minCGPA - 0.3);
    return countryMatch && degreeMatch && subjectMatch && cgpaFeasible;
  });


  // Push additional universities into matched pool
  const extraUnis = [
    { name:"Univ. of Washington", country:"🇺🇸 USA", rank:"QS #92", minCGPA:2.9, idealCGPA:3.3, subjects:["cs-it","eee","physics-math","all"], degrees:["masters","phd"], countries:["usa","any"], funding:true, cost:33000, currency:"USD", scholarships:["Graduate RA/TA"], pr:"OPT/STEM OPT", notes:"Strong BD alumni in CS/EE" },
    { name:"Carnegie Mellon University", country:"🇺🇸 USA", rank:"QS #52", minCGPA:3.2, idealCGPA:3.7, subjects:["cs-it","eee","physics-math","business-mba"], degrees:["masters","phd","mba"], countries:["usa","any"], funding:true, cost:52000, currency:"USD", scholarships:["University Fellowship","RA/TA"], pr:"OPT/STEM OPT", notes:"CS #1 World — PhD fully funded" },
    { name:"Purdue University", country:"🇺🇸 USA", rank:"QS #109", minCGPA:2.9, idealCGPA:3.2, subjects:["cs-it","eee","mech-civil","physics-math"], degrees:["masters","phd"], countries:["usa","any"], funding:true, cost:28500, currency:"USD", scholarships:["Graduate RA","Merit Scholarship"], pr:"OPT/STEM OPT", notes:"Very BD-friendly, large community" },
    { name:"Univ. of Michigan Ann Arbor", country:"🇺🇸 USA", rank:"QS #23", minCGPA:3.0, idealCGPA:3.5, subjects:["cs-it","eee","mech-civil","physics-math"], degrees:["masters","phd"], countries:["usa","any"], funding:true, cost:47000, currency:"USD", scholarships:["Rackham Fellowship","RA/TA"], pr:"OPT/STEM OPT", notes:"Top Engineering, email Prof early" },
    { name:"McMaster University", country:"🇨🇦 Canada", rank:"QS #189", minCGPA:2.8, idealCGPA:3.0, subjects:["cs-it","eee","mech-civil","life-science","all"], degrees:["masters","phd"], countries:["canada","any"], funding:true, cost:19500, currency:"CAD", scholarships:["Graduate TA","Hamilton Grant"], pr:"PGWP + Ontario PNP", notes:"Low cost, underrated gem" },
    { name:"Western University", country:"🇨🇦 Canada", rank:"QS #172", minCGPA:2.7, idealCGPA:3.0, subjects:["cs-it","business-mba","all"], degrees:["masters","phd","mba"], countries:["canada","any"], funding:true, cost:21000, currency:"CAD", scholarships:["Western Graduate Research Scholarship"], pr:"PGWP + Ontario PNP", notes:"CGPA 2.8 acceptable, Ivey Business" },
    { name:"Humboldt University Berlin", country:"🇩🇪 Germany", rank:"QS #120", minCGPA:2.5, idealCGPA:2.7, subjects:["cs-it","physics-math","life-science","economics"], degrees:["masters","phd"], countries:["germany","any"], funding:true, cost:330, currency:"EUR", scholarships:["DAAD Fellowship","Erasmus+"], pr:"18-month Job Seeker Visa", notes:"Berlin tech hub, English CS programs" },
    { name:"University of Hamburg", country:"🇩🇪 Germany", rank:"QS #201", minCGPA:2.5, idealCGPA:2.6, subjects:["cs-it","physics-math","economics","all"], degrees:["masters","phd"], countries:["germany","any"], funding:true, cost:340, currency:"EUR", scholarships:["DAAD Scholarship","Hamburg Merit Award"], pr:"18-month Job Seeker Visa", notes:"BD-friendly, port city, English CS" },
    { name:"University of Glasgow", country:"🇬🇧 UK", rank:"QS #76", minCGPA:2.9, idealCGPA:3.2, subjects:["cs-it","eee","mech-civil","life-science","all"], degrees:["masters","phd"], countries:["uk","any"], funding:true, cost:22000, currency:"GBP", scholarships:["Saltire Scholarship","Glasgow Merit"], pr:"Graduate Route 2yr", notes:"Russell Group, affordable Glasgow city" },
    { name:"University of Warwick", country:"🇬🇧 UK", rank:"QS #67", minCGPA:3.0, idealCGPA:3.4, subjects:["cs-it","business-mba","economics","physics-math"], degrees:["masters","phd","mba"], countries:["uk","any"], funding:true, cost:24500, currency:"GBP", scholarships:["Warwick Scholarship","Chancellor's International"], pr:"Graduate Route 2yr", notes:"Strong industry links, focused campus" },
  ];
  extraUnis.forEach(u => {
    const cM = country === '' || country === 'any' || u.countries.includes(country) || u.countries.includes('any');
    const dM = degree === '' || u.degrees.includes(degree);
    const sM = u.subjects.includes(subject) || u.subjects.includes('all');
    const gM = cgpa >= (u.minCGPA - 0.3);
    if (cM && dM && sM && gM && !matched.find(m => m.name === u.name)) matched.push(u);
  });

  // Sort and tag each as reach/target/safety
  matched = matched.map(u => {
    let tag = 'target';
    if (cgpa < u.minCGPA) tag = 'reach';
    else if (cgpa >= u.idealCGPA) tag = 'safety';
    else if (cgpa >= u.minCGPA && cgpa < u.idealCGPA) tag = 'target';
    let score = 0;
    if (tag === 'safety') score += 30;
    if (tag === 'target') score += 20;
    if (tag === 'reach') score += 5;
    if (u.funding && (budget === 'need-full')) score += 20;
    if (priority === 'research-career' && u.funding) score += 15;
    if (priority === 'pr-immigration' && (u.country.includes('Canada'))) score += 15;
    if (priority === 'fast-pr' && u.pr && u.pr.includes('fast')) score += 20;
    if (priority === 'low-cost' && u.country.includes('Germany')) score += 20;
    if (priority === 'top-brand' && (u.rank.includes('#1') || u.rank.includes('#3') || u.rank.includes('#4') || u.rank.includes('#2') || u.rank.includes('#5'))) score += 10;
    if (research !== 'none' && research !== 'thesis-only' && u.funding) score += 10;
    return { ...u, tag, score };
  }).sort((a, b) => b.score - a.score).slice(0, 8);

  // Filter scholarships
  let scholarships = scholarshipDB.filter(s => {
    const countryMatch = country === '' || country === 'any' || s.country.toLowerCase().includes(country) || s.country === 'Europe';
    const cgpaOk = cgpa >= (s.minCGPA - 0.1);
    const degreeOk = s.forDegrees.includes(degree) || degree === '';
    const subjectOk = s.subjects === 'all' || s.subjects.includes(subject);
    return countryMatch && cgpaOk && degreeOk && subjectOk;
  }).slice(0, 5);

  // Overall profile assessment
  let profileScore, profileClass, profileMsg;
  if (cgpa >= 3.5 && research !== 'none') {
    profileScore = '92%'; profileClass = 'good';
    profileMsg = '🌟 Excellent profile! তুমি top-tier universities-এ directly apply করতে পারো। Fully funded PhD তোমার reach-এ আছে।';
  } else if (cgpa >= 3.0 && (research !== 'none' || gre === '310-319' || gre === '320+')) {
    profileScore = '75%'; profileClass = 'good';
    profileMsg = '✅ Strong profile! Good tier universities-এ তোমার solid chance আছে। Research strengthen করো — top tier possible।';
  } else if (cgpa >= 2.8 || research !== 'none') {
    profileScore = '58%'; profileClass = 'fair';
    profileMsg = '⚡ Decent profile with room to grow। Mid-tier universities-এ strong chance। Research publication দিলে top-tier-ও open হবে।';
  } else if (cgpa >= 2.5) {
    profileScore = '38%'; profileClass = 'fair';
    profileMsg = '🔧 Needs strengthening। Germany (free tuition) বা Canada mid-tier best option। Research + cold email দিয়ে chance বাড়াও।';
  } else {
    profileScore = '22%'; profileClass = 'hard';
    profileMsg = '⚠️ Challenging profile। কিন্তু impossible না। Germany free tuition programs, foundation courses, অথবা research publication দিয়ে gap fill করো।';
  }

  // Cost estimate
  const targetCountry = country === 'any' || !country ? 'usa' : country;
  const costGuide = { usa: { tuition: 30000, living: 16000, currency: 'USD' }, canada: { tuition: 18000, living: 12000, currency: 'CAD' }, germany: { tuition: 400, living: 10000, currency: 'EUR' }, uk: { tuition: 24000, living: 14000, currency: 'GBP' } };
  const cg = costGuide[targetCountry] || costGuide['usa'];
  const rate = exchangeApprox[cg.currency] || 110;
  const totalCost = (cg.tuition + cg.living) * rate;
  const solvency = totalCost * 1.5;

  // Action steps
  const steps = buildActionSteps(cgpa, research, ielts, gre, year, degree, priority, country);

  // Build result HTML
  const reachCount = matched.filter(u => u.tag === 'reach').length;
  const targetCount = matched.filter(u => u.tag === 'target').length;
  const safetyCount = matched.filter(u => u.tag === 'safety').length;

  const uniHTML = matched.map(u => `
    <div class="matched-uni-card">
      <div>
        <div class="muc-name">${u.name}</div>
        <div class="muc-country">${u.country} &nbsp;·&nbsp; ${u.rank}</div>
        <div class="muc-tags">
          <span class="muc-tag ${u.tag}">${u.tag === 'reach' ? '🎯 Reach' : u.tag === 'target' ? '✅ Target' : '🟢 Safety'}</span>
          ${u.funding ? '<span class="muc-tag funded">💰 Funding Available</span>' : ''}
          <span class="muc-tag target" style="background:rgba(255,255,255,0.05);color:var(--fog);border-color:transparent;">${u.notes}</span>
        </div>
      </div>
      <div class="muc-cgpa">
        <span class="cgpa-num" style="color:${cgpa >= u.minCGPA ? 'var(--emerald-light)' : 'var(--danger)'}">${cgpa >= u.minCGPA ? '✓' : '!'}</span>
        <span style="font-size:0.72rem;color:var(--muted);font-weight:700;">Min CGPA<br>${u.minCGPA}</span>
      </div>
    </div>`).join('');

  const schHTML = scholarships.length ? scholarships.map(s => `
    <div class="sch-match-card">
      <div class="smc-name">${s.name}</div>
      <div class="smc-row">
        <span class="smc-pill ${s.type}">${s.type === 'full' ? '✅ Fully Funded' : '🔵 Partial'}</span>
        <span class="smc-amount">${s.bdt}</span>
        <span class="smc-deadline">Deadline: ${s.deadline}</span>
      </div>
    </div>`).join('') : '<p style="color:var(--muted);font-size:0.9rem;padding:0.5rem 0;">Profile adjust করলে আরো scholarships দেখা যাবে।</p>';

  const stepsHTML = steps.map((s, i) => `
    <li>
      <span class="action-step-num ${i < 3 ? '' : i < 6 ? 'green' : 'blue'}">${i+1}</span>
      <span>${s}</span>
    </li>`).join('');

  // Visa quick info
  const visaInfo = getVisaInfo(country, degree);

  document.getElementById('matcher-results').innerHTML = `
    <div class="profile-summary">
      <div>
        <div class="ps-label">Your Profile</div>
        <div class="ps-val">CGPA ${cgpaRange} · ${subject.replace(/-/g,' ').toUpperCase()} · ${degree.toUpperCase()}</div>
      </div>
      <div style="display:flex;gap:0.4rem;flex-wrap:wrap;">
        <span class="profile-pill">${reachCount} Reach</span>
        <span class="profile-pill green">${targetCount} Target</span>
        <span class="profile-pill blue">${safetyCount} Safety</span>
      </div>
    </div>

    <div class="match-banner ${profileClass}">
      <div class="mb-text">${profileMsg}</div>
      <div class="match-score">${profileScore}</div>
    </div>

    <div class="res-section">
      <div class="res-section-title">🎓 Matched Universities (${matched.length} found)</div>
      ${uniHTML || '<p style="color:var(--muted)">No exact match found — try broadening your country preference.</p>'}
    </div>

    <div class="res-section">
      <div class="res-section-title">🏆 Available Scholarships for Your Profile</div>
      ${schHTML}
    </div>

    <div class="res-section">
      <div class="res-section-title">💰 Estimated Annual Cost</div>
      <div class="cost-estimate-box">
        <div class="ce-item">
          <div class="ce-label">Tuition</div>
          <div class="ce-value">৳${Math.round(cg.tuition * rate / 100000).toLocaleString()} Lac</div>
          <div class="ce-note">${cg.currency} ${cg.tuition.toLocaleString()}/yr</div>
        </div>
        <div class="ce-item">
          <div class="ce-label">Living + Other</div>
          <div class="ce-value">৳${Math.round(cg.living * rate / 100000).toLocaleString()} Lac</div>
          <div class="ce-note">${cg.currency} ${cg.living.toLocaleString()}/yr</div>
        </div>
        <div class="ce-item">
          <div class="ce-label">Bank Solvency Needed</div>
          <div class="ce-value">৳${Math.round(solvency / 100000).toLocaleString()} Lac</div>
          <div class="ce-note">Total × 1.5 (visa req.)</div>
        </div>
      </div>
    </div>

    <div class="res-section">
      <div class="res-section-title">🛂 Visa Quick Info</div>
      <div class="visa-quick">${visaInfo}
      <div class="tier-section">
        <div class="tier-badge" style="background:rgba(96,165,250,0.1);border:1px solid rgba(96,165,250,0.3);color:var(--sky);">🆕 Additional Universities — Direct Links</div>
        <div class="uni-grid">
          <div class="uni-card">
            <div class="uni-name">University of Edinburgh</div>
            <div class="uni-rank">📊 QS #22 | CS Top 5 UK</div>
            <div class="uni-details">
              <div class="uni-detail"><div class="key">Min GPA (Official)</div><div class="val">3.2/4.0</div></div>
              <div class="uni-detail"><div class="key">Hidden Cutoff</div><div class="val warning">3.5+ competitive</div></div>
              <div class="uni-detail"><div class="key">GRE Requirement</div><div class="val">Not Required</div></div>
              <div class="uni-detail"><div class="key">IELTS Min</div><div class="val">6.5 (UKVI)</div></div>
              <div class="uni-detail"><div class="key">Annual Tuition</div><div class="val">GBP 26,000</div></div>
              <div class="uni-detail"><div class="key">BD Students/Year</div><div class="val warning">~15-20</div></div>
            </div>
            <div class="scholarship-tags"><span class="s-tag partial">Edinburgh Global Scholarship</span><span class="s-tag partial">Commonwealth Scholarship</span></div>
            <div class="hidden-req"><strong>🔍 Hidden Requirement:</strong> Scotland's top uni. 1-year Masters = cost effective. Edinburgh = beautiful safe city. Graduate Route Visa 2 years work.</div>
            <a href="https://www.ed.ac.uk" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:0.4rem;margin-top:0.8rem;font-size:0.78rem;font-weight:800;color:var(--sky);text-decoration:none;background:rgba(96,165,250,0.08);border:1px solid rgba(96,165,250,0.25);padding:0.3rem 0.85rem;border-radius:6px;transition:all 0.2s;" onmouseover="this.style.background='rgba(96,165,250,0.18)'" onmouseout="this.style.background='rgba(96,165,250,0.08)'">🔗 Official Website ↗</a>
          </div>
          <div class="uni-card">
            <div class="uni-name">University of Glasgow</div>
            <div class="uni-rank">📊 QS #76 | Russell Group</div>
            <div class="uni-details">
              <div class="uni-detail"><div class="key">Min GPA (Official)</div><div class="val">3.0/4.0</div></div>
              <div class="uni-detail"><div class="key">Hidden Cutoff</div><div class="val warning">3.2+ competitive</div></div>
              <div class="uni-detail"><div class="key">GRE Requirement</div><div class="val">Not Required</div></div>
              <div class="uni-detail"><div class="key">IELTS Min</div><div class="val">6.5 (UKVI)</div></div>
              <div class="uni-detail"><div class="key">Annual Tuition</div><div class="val">GBP 22,000</div></div>
              <div class="uni-detail"><div class="key">BD Students/Year</div><div class="val warning">~20-30</div></div>
            </div>
            <div class="scholarship-tags"><span class="s-tag partial">Saltire Scholarship</span><span class="s-tag partial">Glasgow Merit Scholarship</span></div>
            <div class="hidden-req"><strong>🔍 Hidden Requirement:</strong> Russell Group university. Strong BD alumni. Glasgow = affordable UK city. CS/Engineering/Medicine excellent.</div>
            <a href="https://www.gla.ac.uk" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:0.4rem;margin-top:0.8rem;font-size:0.78rem;font-weight:800;color:var(--sky);text-decoration:none;background:rgba(96,165,250,0.08);border:1px solid rgba(96,165,250,0.25);padding:0.3rem 0.85rem;border-radius:6px;transition:all 0.2s;" onmouseover="this.style.background='rgba(96,165,250,0.18)'" onmouseout="this.style.background='rgba(96,165,250,0.08)'">🔗 Official Website ↗</a>
          </div>
          <div class="uni-card">
            <div class="uni-name">University of Warwick</div>
            <div class="uni-rank">📊 QS #67 | Business & CS Strong</div>
            <div class="uni-details">
              <div class="uni-detail"><div class="key">Min GPA (Official)</div><div class="val">3.2/4.0</div></div>
              <div class="uni-detail"><div class="key">Hidden Cutoff</div><div class="val warning">3.4+ competitive</div></div>
              <div class="uni-detail"><div class="key">GRE Requirement</div><div class="val">Not Required</div></div>
              <div class="uni-detail"><div class="key">IELTS Min</div><div class="val">6.5 (UKVI)</div></div>
              <div class="uni-detail"><div class="key">Annual Tuition</div><div class="val">GBP 24,500</div></div>
              <div class="uni-detail"><div class="key">BD Students/Year</div><div class="val warning">~20-25</div></div>
            </div>
            <div class="scholarship-tags"><span class="s-tag partial">Warwick Scholarship</span><span class="s-tag partial">Chancellor's International Scholarship</span></div>
            <div class="hidden-req"><strong>🔍 Hidden Requirement:</strong> Coventry campus = safe and focused. Strong industry links. WMG department world-leading for manufacturing/data.</div>
            <a href="https://warwick.ac.uk" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:0.4rem;margin-top:0.8rem;font-size:0.78rem;font-weight:800;color:var(--sky);text-decoration:none;background:rgba(96,165,250,0.08);border:1px solid rgba(96,165,250,0.25);padding:0.3rem 0.85rem;border-radius:6px;transition:all 0.2s;" onmouseover="this.style.background='rgba(96,165,250,0.18)'" onmouseout="this.style.background='rgba(96,165,250,0.08)'">🔗 Official Website ↗</a>
          </div>
        </div>
      </div>
    </div>
    </div>

    <div class="res-section">
      <div class="res-section-title">📋 Your Personalized Action Plan</div>
      <ul class="action-steps">${stepsHTML}</ul>
    </div>
  `;
  document.getElementById('matcher-results').scrollIntoView({ behavior:'smooth', block:'start' });
}

function buildActionSteps(cgpa, research, ielts, gre, year, degree, priority, country) {
  const steps = [];
  if (ielts === 'none' || ielts === 'below6') steps.push('📖 <strong>IELTS শুরু করো এখনই</strong> — Cambridge IELTS 14-18 books কেনো। Target: 6.5+ (7.0 ideal). British Council Dhaka-তে register করো।');
  else if (ielts === '6.0-6.4') steps.push('📖 <strong>IELTS retake করো</strong> — তোমার current score (6.0-6.4) কিছু universities-এর জন্য কম। Writing score বাড়াও।');
  else steps.push('✅ <strong>IELTS score good আছে!</strong> Score validity 2 years — expiry date check করে রাখো।');

  if (research === 'none' || research === 'thesis-only') {
    steps.push('🔬 <strong>Research শুরু করো এখনই</strong> — Supervisor-এর সাথে কথা বলো। IEEE Access বা MDPI-তে submit করার জন্য কাজ শুরু করো। Low CGPA-র জন্য এটাই সবচেয়ে powerful tool।');
  } else if (research === 'conference') {
    steps.push('🔬 <strong>Research upgrade করো</strong> — Conference paper আছে, এখন journal paper target করো। arXiv preprint দিলে admission committee দেখতে পাবে।');
  } else {
    steps.push('🏆 <strong>Research profile excellent!</strong> Publication list তোমার SOP-এ prominently mention করো। Google Scholar profile create করো।');
  }

  if (degree === 'phd') {
    steps.push('📧 <strong>Professor cold email শুরু করো</strong> — Target 30-50 professors in your field। তাদের latest 2 papers পড়ে specific comment করো। Template আমাদের Research-First section-এ আছে।');
  }

  if (cgpa < 3.0) {
    steps.push('📝 <strong>SOP-এ CGPA reframe করো</strong> — "My CGPA of '+cgpa.toFixed(1)+' reflects..." দিয়ে শুরু করে research/project achievements-এ pivot করো। Upward trend থাকলে explicitly mention করো।');
    steps.push('🎯 <strong>University Selection Strategy</strong> — তোমার CGPA-র জন্য: 5 Safety + 5 Target + 3 Reach = মোট 13টা apply করো। Germany route-ও strongly consider করো (GPA কম important)।');
  }

  if (country === 'germany' || country === 'any') {
    steps.push('🇩🇪 <strong>APS Certificate apply করো</strong> — Germany-র জন্য mandatory। German Embassy Dhaka education section-এ apply করো। Process: 3-4 months। আজই শুরু করো।');
    steps.push('🏦 <strong>Blocked Account তৈরি করো</strong> — Germany visa-র জন্য EUR 11,904 blocked account প্রয়োজন। Fintiba.com ব্যবহার করো — Bangladesh থেকে setup করা যায়।');
  }

  if (country === 'canada' || country === 'any') {
    steps.push('🇨🇦 <strong>GIC তৈরি করো (Canada)</strong> — SDS route-এর জন্য CAD 10,000 Guaranteed Investment Certificate করো। CIBC/ScotiaBank Bangladesh branch-এ করা যায়।');
  }

  if (gre === 'none' && (country === 'usa' || country === 'any') && degree !== 'bachelors') {
    steps.push('📐 <strong>GRE consider করো</strong> — GRE optional হলেও 320+ score তোমার application strong করে। BUET/CS background হলে Q167+ possible। 5 months prep plan করো।');
  }

  steps.push('📄 <strong>LOR request করো</strong> — 3 জন professor-কে এখনই approach করো। "LOR package" দাও: তোমার CV, draft SOP, research summary। ভালো LOR = strong application।');
  steps.push('💰 <strong>Bank Solvency prepare করো</strong> — Parents/guardian-কে এখনই জানাও। Fixed Deposit open করো 3+ months আগে। Lump sum deposit visa officer detect করে — avoid করো।');

  if (priority === 'pr-immigration') {
    steps.push('🏠 <strong>PR-friendly route বেছে নাও</strong> — Canada Atlantic Program (1-2 yr PR), Manitoba PNP, অথবা BC PNP best options। Germany 18-month job seeker visa = EU Blue Card path।');
  }

  steps.push('🚀 <strong>Application timeline set করো</strong> — October-December: Most US/Canada deadlines। January-February: UK/Germany rolling। আজই calendar mark করো।');
  return steps.slice(0, 8);
}

function getVisaInfo(country, degree) {
  const visas = {
    usa: `<div class="vq-card"><div class="vq-country">🇺🇸 USA — F-1 Student Visa</div><div class="vq-item">Visa Type: <span>F-1 Student Visa</span></div><div class="vq-item">Interview: <span>Required (American Embassy, Bashundhara)</span></div><div class="vq-item">Key Doc: <span>I-20 from university</span></div><div class="vq-item">Processing: <span>2-4 weeks (book early)</span></div><div class="vq-item">Post-study Work: <span>OPT 12 mo / STEM OPT 36 mo</span></div></div>`,
    canada: `<div class="vq-card"><div class="vq-country">🇨🇦 Canada — Study Permit</div><div class="vq-item">Visa Type: <span>Study Permit (online)</span></div><div class="vq-item">Interview: <span>Usually NOT required</span></div><div class="vq-item">Key Doc: <span>Acceptance Letter + GIC</span></div><div class="vq-item">Processing: <span>4-12 weeks (SDS faster)</span></div><div class="vq-item">Post-study Work: <span>PGWP 1-3 years (open)</span></div></div>`,
    germany: `<div class="vq-card"><div class="vq-country">🇩🇪 Germany — National Visa (D)</div><div class="vq-item">Visa Type: <span>National Visa Type D</span></div><div class="vq-item">Interview: <span>VFS Global Dhaka</span></div><div class="vq-item">Key Doc: <span>APS Certificate (mandatory!)</span></div><div class="vq-item">Processing: <span>4-8 weeks</span></div><div class="vq-item">Post-study Work: <span>18-month Job Seeker Visa</span></div></div>`,
    uk: `<div class="vq-card"><div class="vq-country">🇬🇧 UK — Student Visa</div><div class="vq-item">Visa Type: <span>UK Student Visa (gov.uk)</span></div><div class="vq-item">Interview: <span>Usually NOT required</span></div><div class="vq-item">Key Doc: <span>CAS + UKVI IELTS</span></div><div class="vq-item">Processing: <span>3 weeks standard</span></div><div class="vq-item">Post-study Work: <span>Graduate Route 2 years</span></div></div>`,
    australia: `<div class="vq-card"><div class="vq-country">🇦🇺 Australia — Student Visa (500)</div><div class="vq-item">Visa Type: <span>Subclass 500 Student Visa</span></div><div class="vq-item">Interview: <span>Not required (online)</span></div><div class="vq-item">Key Doc: <span>CoE + GTE Statement + Financials</span></div><div class="vq-item">Processing: <span>4-8 weeks</span></div><div class="vq-item">Post-study Work: <span>485 Visa 2-4 years</span></div></div>`,
    japan: `<div class="vq-card"><div class="vq-country">🇯🇵 Japan — Student Visa (CoE)</div><div class="vq-item">Visa Type: <span>Student Visa via CoE</span></div><div class="vq-item">Interview: <span>At Japanese Embassy Dhaka</span></div><div class="vq-item">Key Doc: <span>Certificate of Eligibility (CoE) from university</span></div><div class="vq-item">Processing: <span>4-8 weeks</span></div><div class="vq-item">Post-study Work: <span>Engineer/Specialist Visa + MEXT holders stay easily</span></div></div>`,
    korea: `<div class="vq-card"><div class="vq-country">🇰🇷 South Korea — D-2 Student Visa</div><div class="vq-item">Visa Type: <span>D-2 Student Visa</span></div><div class="vq-item">Interview: <span>Korean Embassy Dhaka</span></div><div class="vq-item">Key Doc: <span>Admission Letter + GKS Certificate (if applicable)</span></div><div class="vq-item">Processing: <span>2-4 weeks</span></div><div class="vq-item">Post-study Work: <span>E-7 Specialist Visa → F-5 PR after 5 years</span></div></div>`,
    china: `<div class="vq-card"><div class="vq-country">🇨🇳 China — X1 Student Visa</div><div class="vq-item">Visa Type: <span>X1 (6+ months) Student Visa</span></div><div class="vq-item">Interview: <span>Chinese Embassy Dhaka (straightforward)</span></div><div class="vq-item">Key Doc: <span>JW201/202 Form + Admission Notice + CSC Letter</span></div><div class="vq-item">Processing: <span>1-3 weeks</span></div><div class="vq-item">Post-study Work: <span>Z Work Visa required (limited options)</span></div></div>`,
    netherlands: `<div class="vq-card"><div class="vq-country">🇳🇱 Netherlands — MVV + VVR</div><div class="vq-item">Visa Type: <span>MVV Entry Visa + VVR Residence Permit</span></div><div class="vq-item">Interview: <span>VFS Global Dhaka</span></div><div class="vq-item">Key Doc: <span>University enrollment + Financial proof</span></div><div class="vq-item">Processing: <span>4-8 weeks</span></div><div class="vq-item">Post-study Work: <span>1-yr Orientation Visa → EU Blue Card</span></div></div>`,
  };
  if (country && country !== 'any' && visas[country]) {
    return visas[country] + `<div class="vq-card" style="grid-column:1/-1;background:rgba(245,166,35,0.04)"><div class="vq-country" style="color:var(--saffron-light);">⚠️ BD-Specific Requirement</div><div class="vq-item">Bank Solvency: <span>Must maintain 3+ months</span></div><div class="vq-item">NID/Passport: <span>6+ months validity required</span></div><div class="vq-item">TB Test: <span>Required for UK; check others</span></div><div class="vq-item">Dhaka Agent: <span>VFS Global (UK/Germany), ustraveldocs.com (USA)</span></div></div>`;
  }
  return Object.values(visas).join('');
}


