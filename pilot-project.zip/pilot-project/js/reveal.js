// ══ Scroll reveal with IntersectionObserver ══
(function() {
  const revealEls = document.querySelectorAll(
    '.stat-card, .fear-card, .uni-card, .job-country-card, ' +
    '.prep-card, .embassy-card, .scholarship-card, ' +
    '.section-title, .section-tag, .section-intro, ' +
    '.timeline .phase, .checklist-item, .strategy-card'
  );
  revealEls.forEach((el, i) => {
    el.classList.add('reveal');
    const delay = (i % 4);
    if (delay > 0) el.classList.add('reveal-delay-' + delay);
  });
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  revealEls.forEach(el => observer.observe(el));
})();

// ══ Animated counter for stat numbers ══
(function() {
  const stats = document.querySelectorAll('.stat-number, .ib-value');
  const parseNum = str => {
    const clean = str.replace(/[^0-9.]/g, '');
    return parseFloat(clean) || 0;
  };
  const formatNum = (num, original) => {
    if (original.includes('Cr'))  return '৳' + num.toFixed(0) + 'Cr';
    if (original.includes('Lac')) return '৳' + num.toFixed(0) + 'Lac';
    if (original.includes('+'))   return num.toFixed(0) + '+';
    if (original.includes('%'))   return num.toFixed(0) + '%';
    if (original.includes('/hr')) return '৳' + num.toFixed(0) + '/hr';
    return num.toFixed(0);
  };
  const animateCounter = (el) => {
    const original = el.textContent.trim();
    const target = parseNum(original);
    if (!target) return;
    const duration = 1400;
    const start = performance.now();
    const tick = (now) => {
      const p = Math.min((now - start) / duration, 1);
      const ease = 1 - Math.pow(1 - p, 3);
      el.textContent = formatNum(target * ease, original);
      if (p < 1) requestAnimationFrame(tick);
      else el.textContent = original;
    };
    requestAnimationFrame(tick);
  };
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        animateCounter(e.target);
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.5 });
  stats.forEach(el => observer.observe(el));
})();

// ══ Smooth advisor panel toggle (override display:none) — handled by toggleAdvisor() above ══

// ══ Ripple effect on primary buttons ══
document.querySelectorAll('.btn-primary:not(.wizard-nav .btn-primary), .find-btn').forEach(btn => {
  btn.addEventListener('click', function(e) {
    const rect = btn.getBoundingClientRect();
    const ripple = document.createElement('span');
    const size = Math.max(rect.width, rect.height);
    ripple.style.cssText = 'position:absolute;border-radius:50%;background:rgba(255,255,255,0.3);' +
      'width:' + size + 'px;height:' + size + 'px;' +
      'top:' + (e.clientY - rect.top - size/2) + 'px;' +
      'left:' + (e.clientX - rect.left - size/2) + 'px;' +
      'transform:scale(0);animation:ripple 0.55s cubic-bezier(.4,0,.2,1) forwards;pointer-events:none;';
    btn.style.position = 'relative';
    btn.style.overflow = 'hidden';
    btn.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
  });
});


