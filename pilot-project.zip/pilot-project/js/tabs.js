// ===== TAB SYSTEM — University =====
function showTab(id, btn) {
  document.querySelectorAll('#universities .tab-content').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('#universities .tab-btn').forEach(el => el.classList.remove('active'));
  const tabEl = document.getElementById(id);
  if (tabEl) tabEl.classList.add('active');
  const activeBtn = btn || (window._lastTabBtn);
  if (activeBtn) activeBtn.classList.add('active');
}

// ===== TAB SYSTEM — Checklist =====
function showChecklist(id, btn) {
  document.querySelectorAll('#checklist .tab-content').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('#checklist .tab-btn').forEach(el => el.classList.remove('active'));
  const tabEl = document.getElementById(id);
  if (tabEl) tabEl.classList.add('active');
  const activeBtn = btn || (window._lastTabBtn);
  if (activeBtn) activeBtn.classList.add('active');
}

calculateCost();

