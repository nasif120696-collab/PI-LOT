# ✈️ PiLOT — Don't just dream of flying. Pilot it.

A free, open-source study-abroad guidance platform built specifically for **Bangladeshi students**. PiLOT covers everything from university selection and scholarships to live cost estimation, document checklists, AI-powered SOP review, and professor cold-email generation.

---

## 📁 Project Structure

```
pilot/
│
├── index.html                        ← Entry point (deploy this)
│
├── css/
│   ├── theme.css                     ← CSS variables, dark & light color tokens
│   ├── components.css                ← Nav, hero, cards, buttons, modals, sections
│   ├── animations.css                ← Keyframes, scroll-reveal, ripple effects
│   └── matcher.css                   ← Profile matcher, advisor panel, new tool styles
│
├── js/
│   ├── calculator.js                 ← Cost calculator data + calculateCost()
│   ├── matcher.js                    ← Profile matcher engine + runMatcher()
│   ├── tabs.js                       ← University & checklist tab switchers
│   ├── tools.js                      ← SOP reviewer, cold email, deadline tracker,
│   │                                    cost map, PDF generator, bank guide
│   ├── ui.js                         ← Reading bar, wizard, FAB, advisor chat,
│   │                                    toast, compare modal, theme toggle, mobile nav
│   ├── search.js                     ← Smart search index + initSearch() + nav arrows
│   └── reveal.js                     ← Scroll-reveal observer, animated counters, ripple
│
├── sections/                         ← Each page section as a standalone HTML partial
│   ├── nav.html                      ← Fixed top nav: brand, links, search, theme toggle
│   ├── search-bar.html               ← Smart search bar + mobile nav drawer
│   ├── overlays.html                 ← Reading bar, wizard, compare modal, progress
│   │                                    tracker, insight bar, advisor, FAB, back-to-top
│   ├── hero.html                     ← Animated SVG logo, headline, stat cards, CTAs
│   ├── profile-matcher.html          ← Smart Profile Matcher: form + live results
│   ├── fear-mindset.html             ← Mindset Reset: 3 fears + solutions
│   ├── cost-engine.html              ← Live BDT cost calculator
│   ├── universities-main.html        ← USA, Canada, Germany, UK tabs
│   ├── universities-australia.html   ← Australia universities
│   ├── universities-japan.html       ← Japan + MEXT scholarship
│   ├── universities-korea.html       ← South Korea + GKS scholarship
│   ├── universities-china.html       ← China + CSC scholarship
│   ├── universities-europe.html      ← Europe unis + full scholarship table
│   ├── research-first.html           ← Research-First Strategy (low CGPA guide)
│   ├── test-prep.html                ← IELTS / TOEFL / GRE / GMAT / SAT tabs
│   ├── checklist.html                ← Document checklist by country
│   ├── calendar-365.html             ← 365-day month-by-month action plan
│   ├── jobs.html                     ← Part-time jobs abroad by country
│   ├── embassy-tips.html             ← Embassy interview dos & don'ts
│   ├── motivation.html               ← Banglish motivational copy section
│   ├── sop-reviewer.html             ← AI-powered SOP reviewer tool
│   ├── cold-email.html               ← Professor cold-email generator
│   ├── alumni-stories.html           ← Real BD student success stories
│   ├── deadline-reminder.html        ← Scholarship deadline tracker
│   ├── cost-map.html                 ← Country-by-country cost comparison map
│   ├── pdf-download.html             ← Guide PDF download section
│   ├── bank-guide.html               ← Bank solvency document guide
│   └── footer.html                   ← Footer: brand, links, credits
│
└── assets/                           ← (Place images, icons, fonts here if needed)
```

---

## ✨ Features

| Feature | File |
|---|---|
| 🎯 Profile Matcher | `sections/profile-matcher.html` + `js/matcher.js` |
| 💰 Live Cost Engine (BDT) | `sections/cost-engine.html` + `js/calculator.js` |
| 🏫 University Database (8 countries) | `sections/universities-*.html` |
| 🏆 Scholarship Guide | `sections/universities-europe.html` |
| ✍️ AI SOP Reviewer | `sections/sop-reviewer.html` + `js/tools.js` |
| 📧 Cold Email Generator | `sections/cold-email.html` + `js/tools.js` |
| 📋 Document Checklist | `sections/checklist.html` |
| 📅 365-Day Action Plan | `sections/calendar-365.html` |
| 🧪 Test Prep (IELTS/GRE/TOEFL/GMAT/SAT) | `sections/test-prep.html` |
| 💼 Part-Time Jobs Guide | `sections/jobs.html` |
| 🏦 Bank Solvency Guide | `sections/bank-guide.html` |
| 🌙 Dark / Light Theme | `css/theme.css` + `js/ui.js` |
| 🔍 Smart Search | `js/search.js` |
| 📱 Fully Responsive | `css/components.css` (responsive block) |

---

## 🚀 Deploy to GitHub Pages

### Step 1 — Create repo & push

```bash
git init
git add .
git commit -m "Initial commit — PiLOT study abroad platform"
git remote add origin https://github.com/YOUR_USERNAME/pilot.git
git branch -M main
git push -u origin main
```

### Step 2 — Enable GitHub Pages

1. Go to your repo → **Settings** → **Pages**
2. Source: **Deploy from a branch**
3. Branch: `main` / folder: `/ (root)`
4. Save — your site goes live at `https://YOUR_USERNAME.github.io/pilot`

---

## 🛠️ Local Development

No build tools needed — pure HTML/CSS/JS.

```bash
# Python (built-in)
python3 -m http.server 8000

# Node
npx serve .

# VS Code
# Install "Live Server" → right-click index.html → Open with Live Server
```

Open `http://localhost:8000`

> **Note:** Open via a local server, not by double-clicking `index.html` directly. Browsers block some features (like localStorage theme persistence) on `file://` URLs.

---

## 🎨 How to Edit

### Add a new university
Edit the relevant `sections/universities-*.html` file. Each university is a `.uni-card` div.

### Change cost data
Open `js/calculator.js` — all tuition, living, and insurance figures are in the `costData` object at the top.

### Add a new section
1. Create `sections/your-section.html` with your HTML
2. Paste it into `index.html` at the right position in the body
3. Add any new styles to `css/components.css`
4. Add any JS to the appropriate `js/` module

### Change colours / theme
All colour tokens live in `css/theme.css` — edit `:root` for dark mode, `[data-theme="light"]` for light mode.

---

## 🧰 Tech Stack

- **HTML5** — semantic markup, no framework
- **CSS3** — custom properties, Grid, Flexbox, `@keyframes`
- **Vanilla JavaScript** — zero dependencies, zero build step
- **Google Fonts** — Playfair Display, Nunito, Hind Siliguri, JetBrains Mono, Orbitron
- **IntersectionObserver API** — scroll-reveal animations
- **localStorage** — theme & wizard state persistence

---

## 🤝 Contributing

1. Fork the repo
2. Create a branch: `git checkout -b feature/your-feature`
3. Make your changes in the relevant `sections/` or `js/` file
4. Commit: `git commit -m "Add: your feature"`
5. Push & open a Pull Request

---

## 📄 License

MIT — free to use, fork, and build on.

---

> *"তুমি কি শুধু স্বপ্ন দেখবে? নাকি সেটা Pilot করবে?"*
> Built with ❤️ for every Bangladeshi student who dares to dream bigger.
